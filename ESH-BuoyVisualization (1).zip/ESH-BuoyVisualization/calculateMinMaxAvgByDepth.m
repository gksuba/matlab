function resultTable = calculateMinMaxAvgByDepth( dataTable, paramName )
%
% Required Inputs:
%   buoyLocation   Location of buoy, used in title of plot
%   dataTable      A table containing all the data for the plot
%   paramName      The name of the param to plot, given as a string

% Add a column which is the depth rounded to an integer value


dataTable.DepthInt = round( dataTable.Depth, 0);

% Calculate the min, max and average for each depth and save in a table
minTable = varfun(@min ,dataTable,'InputVariables', paramName, 'GroupingVariables', 'DepthInt');
maxTable = varfun(@max, dataTable,'InputVariables', paramName, 'GroupingVariables', 'DepthInt');
meanTable = varfun(@mean, dataTable,'InputVariables', paramName, 'GroupingVariables', 'DepthInt');

resultTable = minTable(:, [1,3] );
resultTable = join( resultTable, maxTable(:, [1,3] )    );
resultTable = join( resultTable, meanTable(:, [1,3] )    );

%mabye rename the columsn as just 'min', 'max' and 'avg'?

%Example from wind code:
%NorthStats = varfun(@mean,TopWinds,'InputVariables','MaxTurbidity', 'GroupingVariables', {'IceCover_ConditionsDaily', 'HoursNorth'});


% A way to calculate the mean of all parameters in the table. Requires
% statisitics toolbox
% statarray = grpstats(dataTable,'DepthInt')

